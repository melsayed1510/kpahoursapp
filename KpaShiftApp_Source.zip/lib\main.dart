import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'core/theme/app_theme.dart';
import 'providers/shift_providers.dart';
import 'screens/home_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Create an initial container or override to load persisted preferences
  final container = ProviderContainer();
  final prefsService = container.read(preferencesServiceProvider);
  final savedDuration = await prefsService.loadShiftDuration();
  
  // Override initial shiftDurationProvider state with saved duration
  runApp(
    UncontrolledProviderScope(
      container: container..read(shiftDurationProvider.notifier).state = savedDuration,
      child: const KpaShiftApp(),
    ),
  );
}

class KpaShiftApp extends StatelessWidget {
  const KpaShiftApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'KPA Shift & Attendance',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light,
      // Supporting Arabic RTL
      builder: (context, child) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: child ?? const SizedBox(),
        );
      },
      home: const HomeScreen(),
    );
  }
}
